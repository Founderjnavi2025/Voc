import {
  users,
  chatServers,
  chatBots,
  autoMessages,
  chatMessages,
  chatSessions,
  type User,
  type UpsertUser,
  type ChatServer,
  type InsertChatServer,
  type ChatBot,
  type InsertChatBot,
  type AutoMessage,
  type InsertAutoMessage,
  type ChatMessage,
  type InsertChatMessage,
  type ChatSession,
  type InsertChatSession,
} from "@shared/schema";
import { db } from "./db";
import { eq, desc, and, sql } from "drizzle-orm";

// Interface for storage operations
export interface IStorage {
  // User operations
  // (IMPORTANT) these user operations are mandatory for Replit Auth.
  getUser(id: string): Promise<User | undefined>;
  upsertUser(user: UpsertUser): Promise<User>;
  
  // Chat server operations
  getChatServers(ownerId: string): Promise<ChatServer[]>;
  getChatServerById(id: number): Promise<ChatServer | undefined>;
  getChatServerBySubdomain(subdomain: string): Promise<ChatServer | undefined>;
  createChatServer(server: InsertChatServer): Promise<ChatServer>;
  updateChatServer(id: number, server: Partial<InsertChatServer>): Promise<ChatServer>;
  deleteChatServer(id: number): Promise<void>;
  
  // Chat bot operations
  getChatBotsByServerId(serverId: number): Promise<ChatBot[]>;
  getChatBotById(id: number): Promise<ChatBot | undefined>;
  createChatBot(bot: InsertChatBot): Promise<ChatBot>;
  updateChatBot(id: number, bot: Partial<InsertChatBot>): Promise<ChatBot>;
  deleteChatBot(id: number): Promise<void>;
  
  // Auto message operations
  getAutoMessagesByBotId(botId: number): Promise<AutoMessage[]>;
  createAutoMessage(message: InsertAutoMessage): Promise<AutoMessage>;
  updateAutoMessage(id: number, message: Partial<InsertAutoMessage>): Promise<AutoMessage>;
  deleteAutoMessage(id: number): Promise<void>;
  
  // Chat message operations
  getChatMessagesByServerId(serverId: number, limit?: number): Promise<ChatMessage[]>;
  createChatMessage(message: InsertChatMessage): Promise<ChatMessage>;
  
  // Chat session operations
  getChatSessionsByServerId(serverId: number): Promise<ChatSession[]>;
  getActiveChatSessionsByServerId(serverId: number): Promise<ChatSession[]>;
  createChatSession(session: InsertChatSession): Promise<ChatSession>;
  updateChatSession(id: number, session: Partial<InsertChatSession>): Promise<ChatSession>;
  deactivateChatSession(id: number): Promise<void>;
  
  // Analytics
  getServerStats(ownerId: string): Promise<{
    totalServers: number;
    activeUsers: number;
    activeBots: number;
    messagesToday: number;
  }>;
}

export class DatabaseStorage implements IStorage {
  // User operations
  // (IMPORTANT) these user operations are mandatory for Replit Auth.
  async getUser(id: string): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.id, id));
    return user;
  }

  async upsertUser(userData: UpsertUser): Promise<User> {
    const [user] = await db
      .insert(users)
      .values(userData)
      .onConflictDoUpdate({
        target: users.id,
        set: {
          ...userData,
          updatedAt: new Date(),
        },
      })
      .returning();
    return user;
  }

  // Chat server operations
  async getChatServers(ownerId: string): Promise<ChatServer[]> {
    return await db
      .select()
      .from(chatServers)
      .where(eq(chatServers.ownerId, ownerId))
      .orderBy(desc(chatServers.createdAt));
  }

  async getChatServerById(id: number): Promise<ChatServer | undefined> {
    const [server] = await db
      .select()
      .from(chatServers)
      .where(eq(chatServers.id, id));
    return server;
  }

  async getChatServerBySubdomain(subdomain: string): Promise<ChatServer | undefined> {
    const [server] = await db
      .select()
      .from(chatServers)
      .where(eq(chatServers.subdomain, subdomain));
    return server;
  }

  async createChatServer(server: InsertChatServer): Promise<ChatServer> {
    const [newServer] = await db
      .insert(chatServers)
      .values(server)
      .returning();
    return newServer;
  }

  async updateChatServer(id: number, server: Partial<InsertChatServer>): Promise<ChatServer> {
    const [updatedServer] = await db
      .update(chatServers)
      .set({ ...server, updatedAt: new Date() })
      .where(eq(chatServers.id, id))
      .returning();
    return updatedServer;
  }

  async deleteChatServer(id: number): Promise<void> {
    await db.delete(chatServers).where(eq(chatServers.id, id));
  }

  // Chat bot operations
  async getChatBotsByServerId(serverId: number): Promise<ChatBot[]> {
    return await db
      .select()
      .from(chatBots)
      .where(eq(chatBots.serverId, serverId))
      .orderBy(desc(chatBots.createdAt));
  }

  async getChatBotById(id: number): Promise<ChatBot | undefined> {
    const [bot] = await db
      .select()
      .from(chatBots)
      .where(eq(chatBots.id, id));
    return bot;
  }

  async createChatBot(bot: InsertChatBot): Promise<ChatBot> {
    const [newBot] = await db
      .insert(chatBots)
      .values(bot)
      .returning();
    return newBot;
  }

  async updateChatBot(id: number, bot: Partial<InsertChatBot>): Promise<ChatBot> {
    const [updatedBot] = await db
      .update(chatBots)
      .set({ ...bot, updatedAt: new Date() })
      .where(eq(chatBots.id, id))
      .returning();
    return updatedBot;
  }

  async deleteChatBot(id: number): Promise<void> {
    await db.delete(chatBots).where(eq(chatBots.id, id));
  }

  // Auto message operations
  async getAutoMessagesByBotId(botId: number): Promise<AutoMessage[]> {
    return await db
      .select()
      .from(autoMessages)
      .where(eq(autoMessages.botId, botId))
      .orderBy(desc(autoMessages.createdAt));
  }

  async createAutoMessage(message: InsertAutoMessage): Promise<AutoMessage> {
    const [newMessage] = await db
      .insert(autoMessages)
      .values(message)
      .returning();
    return newMessage;
  }

  async updateAutoMessage(id: number, message: Partial<InsertAutoMessage>): Promise<AutoMessage> {
    const [updatedMessage] = await db
      .update(autoMessages)
      .set(message)
      .where(eq(autoMessages.id, id))
      .returning();
    return updatedMessage;
  }

  async deleteAutoMessage(id: number): Promise<void> {
    await db.delete(autoMessages).where(eq(autoMessages.id, id));
  }

  // Chat message operations
  async getChatMessagesByServerId(serverId: number, limit: number = 50): Promise<ChatMessage[]> {
    return await db
      .select()
      .from(chatMessages)
      .where(eq(chatMessages.serverId, serverId))
      .orderBy(desc(chatMessages.createdAt))
      .limit(limit);
  }

  async createChatMessage(message: InsertChatMessage): Promise<ChatMessage> {
    const [newMessage] = await db
      .insert(chatMessages)
      .values(message)
      .returning();
    return newMessage;
  }

  // Chat session operations
  async getChatSessionsByServerId(serverId: number): Promise<ChatSession[]> {
    return await db
      .select()
      .from(chatSessions)
      .where(eq(chatSessions.serverId, serverId))
      .orderBy(desc(chatSessions.joinedAt));
  }

  async getActiveChatSessionsByServerId(serverId: number): Promise<ChatSession[]> {
    return await db
      .select()
      .from(chatSessions)
      .where(and(
        eq(chatSessions.serverId, serverId),
        eq(chatSessions.isActive, true)
      ))
      .orderBy(desc(chatSessions.joinedAt));
  }

  async createChatSession(session: InsertChatSession): Promise<ChatSession> {
    const [newSession] = await db
      .insert(chatSessions)
      .values(session)
      .returning();
    return newSession;
  }

  async updateChatSession(id: number, session: Partial<InsertChatSession>): Promise<ChatSession> {
    const [updatedSession] = await db
      .update(chatSessions)
      .set({ ...session, lastActivity: new Date() })
      .where(eq(chatSessions.id, id))
      .returning();
    return updatedSession;
  }

  async deactivateChatSession(id: number): Promise<void> {
    await db
      .update(chatSessions)
      .set({ isActive: false })
      .where(eq(chatSessions.id, id));
  }

  // Analytics
  async getServerStats(ownerId: string): Promise<{
    totalServers: number;
    activeUsers: number;
    activeBots: number;
    messagesToday: number;
  }> {
    const [serverCount] = await db
      .select({ count: sql<number>`count(*)` })
      .from(chatServers)
      .where(eq(chatServers.ownerId, ownerId));

    const [activeUserCount] = await db
      .select({ count: sql<number>`count(distinct ${chatSessions.userId})` })
      .from(chatSessions)
      .innerJoin(chatServers, eq(chatSessions.serverId, chatServers.id))
      .where(and(
        eq(chatServers.ownerId, ownerId),
        eq(chatSessions.isActive, true)
      ));

    const [activeBotCount] = await db
      .select({ count: sql<number>`count(*)` })
      .from(chatBots)
      .innerJoin(chatServers, eq(chatBots.serverId, chatServers.id))
      .where(and(
        eq(chatServers.ownerId, ownerId),
        eq(chatBots.isOnline, true)
      ));

    const today = new Date();
    today.setHours(0, 0, 0, 0);
    const [messagesTodayCount] = await db
      .select({ count: sql<number>`count(*)` })
      .from(chatMessages)
      .innerJoin(chatServers, eq(chatMessages.serverId, chatServers.id))
      .where(and(
        eq(chatServers.ownerId, ownerId),
        sql`${chatMessages.createdAt} >= ${today}`
      ));

    return {
      totalServers: serverCount?.count || 0,
      activeUsers: activeUserCount?.count || 0,
      activeBots: activeBotCount?.count || 0,
      messagesToday: messagesTodayCount?.count || 0,
    };
  }
}

export const storage = new DatabaseStorage();
