import type { Express } from "express";
import { createServer, type Server } from "http";
import { WebSocketServer, WebSocket } from "ws";
import { storage } from "./storage";
import { setupAuth, isAuthenticated } from "./replitAuth";
import { insertChatServerSchema, insertChatBotSchema, insertAutoMessageSchema } from "@shared/schema";
import { z } from "zod";

interface WebSocketMessage {
  type: 'join' | 'leave' | 'message' | 'bot_message';
  serverId?: number;
  userId?: string;
  username?: string;
  message?: string;
  messageType?: string;
  botId?: number;
}

interface ExtendedWebSocket extends WebSocket {
  serverId?: number;
  userId?: string;
  username?: string;
}

export async function registerRoutes(app: Express): Promise<Server> {
  // Auth middleware
  await setupAuth(app);

  // Auth routes
  app.get('/api/auth/user', isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const user = await storage.getUser(userId);
      res.json(user);
    } catch (error) {
      console.error("Error fetching user:", error);
      res.status(500).json({ message: "Failed to fetch user" });
    }
  });

  // Chat server routes
  app.get('/api/chat-servers', isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const servers = await storage.getChatServers(userId);
      res.json(servers);
    } catch (error) {
      console.error("Error fetching chat servers:", error);
      res.status(500).json({ message: "Failed to fetch chat servers" });
    }
  });

  app.post('/api/chat-servers', isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const serverData = insertChatServerSchema.parse({
        ...req.body,
        ownerId: userId,
      });
      
      const server = await storage.createChatServer(serverData);
      res.json(server);
    } catch (error) {
      console.error("Error creating chat server:", error);
      res.status(500).json({ message: "Failed to create chat server" });
    }
  });

  app.get('/api/chat-servers/:id', isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const serverId = parseInt(req.params.id);
      const server = await storage.getChatServerById(serverId);
      
      if (!server || server.ownerId !== userId) {
        return res.status(404).json({ message: "Chat server not found" });
      }
      
      res.json(server);
    } catch (error) {
      console.error("Error fetching chat server:", error);
      res.status(500).json({ message: "Failed to fetch chat server" });
    }
  });

  app.put('/api/chat-servers/:id', isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const serverId = parseInt(req.params.id);
      const server = await storage.getChatServerById(serverId);
      
      if (!server || server.ownerId !== userId) {
        return res.status(404).json({ message: "Chat server not found" });
      }
      
      const updateData = insertChatServerSchema.partial().parse(req.body);
      const updatedServer = await storage.updateChatServer(serverId, updateData);
      res.json(updatedServer);
    } catch (error) {
      console.error("Error updating chat server:", error);
      res.status(500).json({ message: "Failed to update chat server" });
    }
  });

  app.delete('/api/chat-servers/:id', isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const serverId = parseInt(req.params.id);
      const server = await storage.getChatServerById(serverId);
      
      if (!server || server.ownerId !== userId) {
        return res.status(404).json({ message: "Chat server not found" });
      }
      
      await storage.deleteChatServer(serverId);
      res.json({ message: "Chat server deleted successfully" });
    } catch (error) {
      console.error("Error deleting chat server:", error);
      res.status(500).json({ message: "Failed to delete chat server" });
    }
  });

  // Public chat server access
  app.get('/api/public/chat-servers/:subdomain', async (req, res) => {
    try {
      const subdomain = req.params.subdomain;
      const server = await storage.getChatServerBySubdomain(subdomain);
      
      if (!server || !server.isActive) {
        return res.status(404).json({ message: "Chat server not found" });
      }
      
      res.json(server);
    } catch (error) {
      console.error("Error fetching public chat server:", error);
      res.status(500).json({ message: "Failed to fetch chat server" });
    }
  });

  // Chat bot routes
  app.get('/api/chat-servers/:serverId/bots', isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const serverId = parseInt(req.params.serverId);
      const server = await storage.getChatServerById(serverId);
      
      if (!server || server.ownerId !== userId) {
        return res.status(404).json({ message: "Chat server not found" });
      }
      
      const bots = await storage.getChatBotsByServerId(serverId);
      res.json(bots);
    } catch (error) {
      console.error("Error fetching chat bots:", error);
      res.status(500).json({ message: "Failed to fetch chat bots" });
    }
  });

  app.post('/api/chat-servers/:serverId/bots', isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const serverId = parseInt(req.params.serverId);
      const server = await storage.getChatServerById(serverId);
      
      if (!server || server.ownerId !== userId) {
        return res.status(404).json({ message: "Chat server not found" });
      }
      
      const botData = insertChatBotSchema.parse({
        ...req.body,
        serverId,
      });
      
      const bot = await storage.createChatBot(botData);
      res.json(bot);
    } catch (error) {
      console.error("Error creating chat bot:", error);
      res.status(500).json({ message: "Failed to create chat bot" });
    }
  });

  // Auto message routes
  app.get('/api/bots/:botId/auto-messages', isAuthenticated, async (req: any, res) => {
    try {
      const botId = parseInt(req.params.botId);
      const bot = await storage.getChatBotById(botId);
      
      if (!bot) {
        return res.status(404).json({ message: "Bot not found" });
      }
      
      const server = await storage.getChatServerById(bot.serverId);
      if (!server || server.ownerId !== req.user.claims.sub) {
        return res.status(404).json({ message: "Unauthorized" });
      }
      
      const messages = await storage.getAutoMessagesByBotId(botId);
      res.json(messages);
    } catch (error) {
      console.error("Error fetching auto messages:", error);
      res.status(500).json({ message: "Failed to fetch auto messages" });
    }
  });

  app.post('/api/bots/:botId/auto-messages', isAuthenticated, async (req: any, res) => {
    try {
      const botId = parseInt(req.params.botId);
      const bot = await storage.getChatBotById(botId);
      
      if (!bot) {
        return res.status(404).json({ message: "Bot not found" });
      }
      
      const server = await storage.getChatServerById(bot.serverId);
      if (!server || server.ownerId !== req.user.claims.sub) {
        return res.status(404).json({ message: "Unauthorized" });
      }
      
      const messageData = insertAutoMessageSchema.parse({
        ...req.body,
        botId,
      });
      
      const message = await storage.createAutoMessage(messageData);
      res.json(message);
    } catch (error) {
      console.error("Error creating auto message:", error);
      res.status(500).json({ message: "Failed to create auto message" });
    }
  });

  // Chat messages routes
  app.get('/api/chat-servers/:serverId/messages', async (req, res) => {
    try {
      const serverId = parseInt(req.params.serverId);
      const server = await storage.getChatServerById(serverId);
      
      if (!server || !server.isActive) {
        return res.status(404).json({ message: "Chat server not found" });
      }
      
      const messages = await storage.getChatMessagesByServerId(serverId);
      res.json(messages);
    } catch (error) {
      console.error("Error fetching chat messages:", error);
      res.status(500).json({ message: "Failed to fetch chat messages" });
    }
  });

  // Analytics routes
  app.get('/api/analytics/stats', isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const stats = await storage.getServerStats(userId);
      res.json(stats);
    } catch (error) {
      console.error("Error fetching stats:", error);
      res.status(500).json({ message: "Failed to fetch stats" });
    }
  });

  // Active sessions routes
  app.get('/api/chat-servers/:serverId/sessions', async (req, res) => {
    try {
      const serverId = parseInt(req.params.serverId);
      const server = await storage.getChatServerById(serverId);
      
      if (!server || !server.isActive) {
        return res.status(404).json({ message: "Chat server not found" });
      }
      
      const sessions = await storage.getActiveChatSessionsByServerId(serverId);
      res.json(sessions);
    } catch (error) {
      console.error("Error fetching chat sessions:", error);
      res.status(500).json({ message: "Failed to fetch chat sessions" });
    }
  });

  const httpServer = createServer(app);

  // WebSocket server for real-time chat
  const wss = new WebSocketServer({ server: httpServer, path: '/ws' });

  wss.on('connection', (ws: ExtendedWebSocket) => {
    console.log('New WebSocket connection');

    ws.on('message', async (data: Buffer) => {
      try {
        const message: WebSocketMessage = JSON.parse(data.toString());
        
        switch (message.type) {
          case 'join':
            if (message.serverId && message.userId && message.username) {
              ws.serverId = message.serverId;
              ws.userId = message.userId;
              ws.username = message.username;
              
              // Create or update chat session
              await storage.createChatSession({
                serverId: message.serverId,
                userId: message.userId,
                username: message.username,
              });
              
              // Broadcast user joined
              broadcastToServer(message.serverId, {
                type: 'user_joined',
                username: message.username,
                message: `${message.username} joined the chat`,
              });
            }
            break;
            
          case 'message':
            if (ws.serverId && message.message) {
              // Save message to database
              await storage.createChatMessage({
                serverId: ws.serverId,
                userId: ws.userId,
                message: message.message,
                messageType: 'text',
              });
              
              // Broadcast message to all users in the server
              broadcastToServer(ws.serverId, {
                type: 'message',
                userId: ws.userId,
                username: ws.username,
                message: message.message,
                timestamp: new Date().toISOString(),
              });
            }
            break;
            
          case 'leave':
            if (ws.serverId && ws.username) {
              broadcastToServer(ws.serverId, {
                type: 'user_left',
                username: ws.username,
                message: `${ws.username} left the chat`,
              });
            }
            break;
        }
      } catch (error) {
        console.error('WebSocket message error:', error);
      }
    });

    ws.on('close', () => {
      if (ws.serverId && ws.username) {
        broadcastToServer(ws.serverId, {
          type: 'user_left',
          username: ws.username,
          message: `${ws.username} left the chat`,
        });
      }
    });
  });

  function broadcastToServer(serverId: number, message: any) {
    wss.clients.forEach((client: ExtendedWebSocket) => {
      if (client.readyState === WebSocket.OPEN && client.serverId === serverId) {
        client.send(JSON.stringify(message));
      }
    });
  }

  // Bot auto-message system
  setInterval(async () => {
    try {
      // Get all active bots
      const servers = await storage.getChatServers(''); // This would need to be improved for production
      
      for (const server of servers) {
        if (!server.isActive) continue;
        
        const bots = await storage.getChatBotsByServerId(server.id);
        const activeSessions = await storage.getActiveChatSessionsByServerId(server.id);
        
        if (activeSessions.length === 0) continue;
        
        for (const bot of bots) {
          if (!bot.isOnline) continue;
          
          const autoMessages = await storage.getAutoMessagesByBotId(bot.id);
          if (autoMessages.length === 0) continue;
          
          // Send random auto message
          const randomMessage = autoMessages[Math.floor(Math.random() * autoMessages.length)];
          
          // Save bot message to database
          await storage.createChatMessage({
            serverId: server.id,
            botId: bot.id,
            message: randomMessage.message,
            messageType: 'bot_auto',
          });
          
          // Broadcast bot message
          broadcastToServer(server.id, {
            type: 'bot_message',
            botId: bot.id,
            botName: bot.name,
            botAvatar: bot.avatar,
            message: randomMessage.message,
            link: randomMessage.link,
            timestamp: new Date().toISOString(),
          });
        }
      }
    } catch (error) {
      console.error('Auto message error:', error);
    }
  }, 30000); // Send auto messages every 30 seconds

  return httpServer;
}
