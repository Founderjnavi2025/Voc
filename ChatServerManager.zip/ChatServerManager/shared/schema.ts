import {
  pgTable,
  text,
  varchar,
  timestamp,
  jsonb,
  index,
  serial,
  integer,
  boolean,
} from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";
import { relations } from "drizzle-orm";

// Session storage table.
// (IMPORTANT) This table is mandatory for Replit Auth, don't drop it.
export const sessions = pgTable(
  "sessions",
  {
    sid: varchar("sid").primaryKey(),
    sess: jsonb("sess").notNull(),
    expire: timestamp("expire").notNull(),
  },
  (table) => [index("IDX_session_expire").on(table.expire)],
);

// User storage table.
// (IMPORTANT) This table is mandatory for Replit Auth, don't drop it.
export const users = pgTable("users", {
  id: varchar("id").primaryKey().notNull(),
  email: varchar("email").unique(),
  firstName: varchar("first_name"),
  lastName: varchar("last_name"),
  profileImageUrl: varchar("profile_image_url"),
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
});

// Chat servers table
export const chatServers = pgTable("chat_servers", {
  id: serial("id").primaryKey(),
  name: varchar("name").notNull(),
  subdomain: varchar("subdomain").notNull().unique(),
  ownerId: varchar("owner_id").notNull(),
  maxUsers: integer("max_users").default(100),
  chatDuration: integer("chat_duration").default(30), // in minutes
  isActive: boolean("is_active").default(true),
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
});

// Chat bots table
export const chatBots = pgTable("chat_bots", {
  id: serial("id").primaryKey(),
  serverId: integer("server_id").notNull(),
  name: varchar("name").notNull(),
  avatar: varchar("avatar").default("🤖"),
  welcomeMessage: text("welcome_message"),
  autoMessageInterval: integer("auto_message_interval").default(30), // in seconds
  messageDisplayTime: integer("message_display_time").default(10), // in seconds
  isOnline: boolean("is_online").default(true),
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
});

// Auto messages table
export const autoMessages = pgTable("auto_messages", {
  id: serial("id").primaryKey(),
  botId: integer("bot_id").notNull(),
  message: text("message").notNull(),
  link: varchar("link"),
  isActive: boolean("is_active").default(true),
  createdAt: timestamp("created_at").defaultNow(),
});

// Chat messages table
export const chatMessages = pgTable("chat_messages", {
  id: serial("id").primaryKey(),
  serverId: integer("server_id").notNull(),
  userId: varchar("user_id"),
  botId: integer("bot_id"),
  message: text("message").notNull(),
  messageType: varchar("message_type").default("text"), // text, bot_auto, system
  createdAt: timestamp("created_at").defaultNow(),
});

// Active chat sessions table
export const chatSessions = pgTable("chat_sessions", {
  id: serial("id").primaryKey(),
  serverId: integer("server_id").notNull(),
  userId: varchar("user_id"),
  username: varchar("username"),
  joinedAt: timestamp("joined_at").defaultNow(),
  lastActivity: timestamp("last_activity").defaultNow(),
  isActive: boolean("is_active").default(true),
});

// Relations
export const usersRelations = relations(users, ({ many }) => ({
  chatServers: many(chatServers),
  chatMessages: many(chatMessages),
  chatSessions: many(chatSessions),
}));

export const chatServersRelations = relations(chatServers, ({ one, many }) => ({
  owner: one(users, {
    fields: [chatServers.ownerId],
    references: [users.id],
  }),
  bots: many(chatBots),
  messages: many(chatMessages),
  sessions: many(chatSessions),
}));

export const chatBotsRelations = relations(chatBots, ({ one, many }) => ({
  server: one(chatServers, {
    fields: [chatBots.serverId],
    references: [chatServers.id],
  }),
  autoMessages: many(autoMessages),
  messages: many(chatMessages),
}));

export const autoMessagesRelations = relations(autoMessages, ({ one }) => ({
  bot: one(chatBots, {
    fields: [autoMessages.botId],
    references: [chatBots.id],
  }),
}));

export const chatMessagesRelations = relations(chatMessages, ({ one }) => ({
  server: one(chatServers, {
    fields: [chatMessages.serverId],
    references: [chatServers.id],
  }),
  user: one(users, {
    fields: [chatMessages.userId],
    references: [users.id],
  }),
  bot: one(chatBots, {
    fields: [chatMessages.botId],
    references: [chatBots.id],
  }),
}));

export const chatSessionsRelations = relations(chatSessions, ({ one }) => ({
  server: one(chatServers, {
    fields: [chatSessions.serverId],
    references: [chatServers.id],
  }),
  user: one(users, {
    fields: [chatSessions.userId],
    references: [users.id],
  }),
}));

// Insert schemas
export const insertChatServerSchema = createInsertSchema(chatServers).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
});

export const insertChatBotSchema = createInsertSchema(chatBots).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
});

export const insertAutoMessageSchema = createInsertSchema(autoMessages).omit({
  id: true,
  createdAt: true,
});

export const insertChatMessageSchema = createInsertSchema(chatMessages).omit({
  id: true,
  createdAt: true,
});

export const insertChatSessionSchema = createInsertSchema(chatSessions).omit({
  id: true,
  joinedAt: true,
  lastActivity: true,
});

// Types
export type UpsertUser = typeof users.$inferInsert;
export type User = typeof users.$inferSelect;
export type ChatServer = typeof chatServers.$inferSelect;
export type InsertChatServer = z.infer<typeof insertChatServerSchema>;
export type ChatBot = typeof chatBots.$inferSelect;
export type InsertChatBot = z.infer<typeof insertChatBotSchema>;
export type AutoMessage = typeof autoMessages.$inferSelect;
export type InsertAutoMessage = z.infer<typeof insertAutoMessageSchema>;
export type ChatMessage = typeof chatMessages.$inferSelect;
export type InsertChatMessage = z.infer<typeof insertChatMessageSchema>;
export type ChatSession = typeof chatSessions.$inferSelect;
export type InsertChatSession = z.infer<typeof insertChatSessionSchema>;
