import { useState } from "react";
import { useMutation, useQueryClient } from "@tanstack/react-query";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { useToast } from "@/hooks/use-toast";
import { isUnauthorizedError } from "@/lib/authUtils";
import { apiRequest } from "@/lib/queryClient";
import { insertChatServerSchema } from "@shared/schema";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import {
  Form,
  FormControl,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from "@/components/ui/form";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Checkbox } from "@/components/ui/checkbox";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Textarea } from "@/components/ui/textarea";
import { Plus, Trash2 } from "lucide-react";

const createServerSchema = insertChatServerSchema.extend({
  enableBot: z.boolean().default(false),
  botName: z.string().optional(),
  botAvatar: z.string().optional(),
  welcomeMessage: z.string().optional(),
  autoMessageInterval: z.number().min(10).optional(),
  messageDisplayTime: z.number().min(5).optional(),
  autoMessages: z.array(z.object({
    message: z.string(),
    link: z.string().optional(),
  })).optional(),
});

type CreateServerForm = z.infer<typeof createServerSchema>;

interface CreateServerModalProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
}

export function CreateServerModal({ open, onOpenChange }: CreateServerModalProps) {
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const [autoMessages, setAutoMessages] = useState<Array<{ message: string; link: string }>>([
    { message: "", link: "" }
  ]);

  const form = useForm<CreateServerForm>({
    resolver: zodResolver(createServerSchema),
    defaultValues: {
      name: "",
      subdomain: "",
      maxUsers: 100,
      chatDuration: 30,
      isActive: true,
      enableBot: false,
      botName: "",
      botAvatar: "🤖",
      welcomeMessage: "",
      autoMessageInterval: 30,
      messageDisplayTime: 10,
      autoMessages: [{ message: "", link: "" }],
    },
  });

  const createServerMutation = useMutation({
    mutationFn: async (data: CreateServerForm) => {
      // First create the server
      const serverResponse = await apiRequest("POST", "/api/chat-servers", {
        name: data.name,
        subdomain: data.subdomain,
        maxUsers: data.maxUsers,
        chatDuration: data.chatDuration,
        isActive: data.isActive,
      });
      
      const server = await serverResponse.json();
      
      // If bot is enabled, create the bot
      if (data.enableBot) {
        const botResponse = await apiRequest("POST", `/api/chat-servers/${server.id}/bots`, {
          name: data.botName,
          avatar: data.botAvatar,
          welcomeMessage: data.welcomeMessage,
          autoMessageInterval: data.autoMessageInterval,
          messageDisplayTime: data.messageDisplayTime,
          isOnline: true,
        });
        
        const bot = await botResponse.json();
        
        // Create auto messages
        if (data.autoMessages) {
          for (const autoMessage of data.autoMessages) {
            if (autoMessage.message.trim()) {
              await apiRequest("POST", `/api/bots/${bot.id}/auto-messages`, {
                message: autoMessage.message,
                link: autoMessage.link || null,
                isActive: true,
              });
            }
          }
        }
      }
      
      return server;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/chat-servers"] });
      queryClient.invalidateQueries({ queryKey: ["/api/analytics/stats"] });
      toast({
        title: "Success",
        description: "Chat server created successfully",
      });
      onOpenChange(false);
      form.reset();
      setAutoMessages([{ message: "", link: "" }]);
    },
    onError: (error) => {
      if (isUnauthorizedError(error)) {
        toast({
          title: "Unauthorized",
          description: "You are logged out. Logging in again...",
          variant: "destructive",
        });
        setTimeout(() => {
          window.location.href = "/api/login";
        }, 500);
        return;
      }
      toast({
        title: "Error",
        description: "Failed to create chat server",
        variant: "destructive",
      });
    },
  });

  const onSubmit = (data: CreateServerForm) => {
    createServerMutation.mutate({
      ...data,
      autoMessages: autoMessages.filter(msg => msg.message.trim()),
    });
  };

  const addAutoMessage = () => {
    setAutoMessages([...autoMessages, { message: "", link: "" }]);
  };

  const removeAutoMessage = (index: number) => {
    setAutoMessages(autoMessages.filter((_, i) => i !== index));
  };

  const updateAutoMessage = (index: number, field: 'message' | 'link', value: string) => {
    const updated = [...autoMessages];
    updated[index][field] = value;
    setAutoMessages(updated);
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle>Create New Chat Server</DialogTitle>
        </DialogHeader>
        
        <Form {...form}>
          <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-6">
            {/* Server Details */}
            <div className="space-y-4">
              <h3 className="text-lg font-semibold text-gray-800">Server Details</h3>
              
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <FormField
                  control={form.control}
                  name="name"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Server Name</FormLabel>
                      <FormControl>
                        <Input placeholder="e.g., Customer Support" {...field} />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                
                <FormField
                  control={form.control}
                  name="subdomain"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Subdomain</FormLabel>
                      <FormControl>
                        <div className="flex">
                          <Input 
                            placeholder="customer-support" 
                            className="rounded-r-none"
                            {...field} 
                          />
                          <div className="px-3 py-2 bg-gray-100 border border-l-0 border-gray-300 rounded-r-md text-sm text-gray-600">
                            .chat
                          </div>
                        </div>
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
              </div>
              
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <FormField
                  control={form.control}
                  name="chatDuration"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Chat Duration (minutes)</FormLabel>
                      <FormControl>
                        <Input 
                          type="number" 
                          min="1"
                          {...field}
                          onChange={(e) => field.onChange(parseInt(e.target.value))}
                        />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                
                <FormField
                  control={form.control}
                  name="maxUsers"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Max Users</FormLabel>
                      <FormControl>
                        <Input 
                          type="number" 
                          min="1"
                          {...field}
                          onChange={(e) => field.onChange(parseInt(e.target.value))}
                        />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
              </div>
            </div>
            
            {/* Bot Configuration */}
            <div className="space-y-4">
              <div className="flex items-center justify-between">
                <h3 className="text-lg font-semibold text-gray-800">Bot Configuration</h3>
                <FormField
                  control={form.control}
                  name="enableBot"
                  render={({ field }) => (
                    <FormItem className="flex items-center space-x-2">
                      <FormControl>
                        <Checkbox
                          checked={field.value}
                          onCheckedChange={field.onChange}
                        />
                      </FormControl>
                      <FormLabel className="text-sm">Enable Bot</FormLabel>
                    </FormItem>
                  )}
                />
              </div>
              
              {form.watch("enableBot") && (
                <div className="space-y-4">
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <FormField
                      control={form.control}
                      name="botName"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Bot Name</FormLabel>
                          <FormControl>
                            <Input placeholder="Customer Support Bot" {...field} />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                    
                    <FormField
                      control={form.control}
                      name="botAvatar"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Bot Avatar</FormLabel>
                          <Select onValueChange={field.onChange} defaultValue={field.value}>
                            <FormControl>
                              <SelectTrigger>
                                <SelectValue placeholder="Select avatar" />
                              </SelectTrigger>
                            </FormControl>
                            <SelectContent>
                              <SelectItem value="🤖">🤖 Robot</SelectItem>
                              <SelectItem value="👨‍💼">👨‍💼 Support Agent</SelectItem>
                              <SelectItem value="👩‍💼">👩‍💼 Sales Agent</SelectItem>
                              <SelectItem value="🎯">🎯 Assistant</SelectItem>
                            </SelectContent>
                          </Select>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                  </div>
                  
                  <FormField
                    control={form.control}
                    name="welcomeMessage"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Welcome Message</FormLabel>
                        <FormControl>
                          <Textarea 
                            placeholder="Welcome to our chat! How can I help you today?"
                            rows={3}
                            {...field}
                          />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                  
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <FormField
                      control={form.control}
                      name="autoMessageInterval"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Auto Message Interval (seconds)</FormLabel>
                          <FormControl>
                            <Input 
                              type="number" 
                              min="10"
                              {...field}
                              onChange={(e) => field.onChange(parseInt(e.target.value))}
                            />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                    
                    <FormField
                      control={form.control}
                      name="messageDisplayTime"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Message Display Time (seconds)</FormLabel>
                          <FormControl>
                            <Input 
                              type="number" 
                              min="5"
                              {...field}
                              onChange={(e) => field.onChange(parseInt(e.target.value))}
                            />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                  </div>
                  
                  {/* Auto Messages */}
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-2">
                      Auto Messages
                    </label>
                    <div className="space-y-3">
                      {autoMessages.map((autoMessage, index) => (
                        <div key={index} className="flex items-center space-x-3">
                          <Input
                            placeholder="Your auto message"
                            value={autoMessage.message}
                            onChange={(e) => updateAutoMessage(index, 'message', e.target.value)}
                            className="flex-1"
                          />
                          <Input
                            placeholder="https://store.example.com (optional)"
                            value={autoMessage.link}
                            onChange={(e) => updateAutoMessage(index, 'link', e.target.value)}
                            className="flex-1"
                          />
                          <Button
                            type="button"
                            variant="ghost"
                            size="sm"
                            onClick={() => removeAutoMessage(index)}
                            className="text-red-600 hover:text-red-800"
                          >
                            <Trash2 className="w-4 h-4" />
                          </Button>
                        </div>
                      ))}
                    </div>
                    <Button
                      type="button"
                      variant="ghost"
                      size="sm"
                      onClick={addAutoMessage}
                      className="mt-2 text-wa-green hover:text-wa-dark-green"
                    >
                      <Plus className="w-4 h-4 mr-1" />
                      Add Auto Message
                    </Button>
                  </div>
                </div>
              )}
            </div>
            
            <div className="flex justify-end space-x-3 pt-6 border-t">
              <Button
                type="button"
                variant="outline"
                onClick={() => onOpenChange(false)}
              >
                Cancel
              </Button>
              <Button
                type="submit"
                disabled={createServerMutation.isPending}
                className="bg-wa-green hover:bg-wa-dark-green text-white"
              >
                {createServerMutation.isPending ? "Creating..." : "Create Server"}
              </Button>
            </div>
          </form>
        </Form>
      </DialogContent>
    </Dialog>
  );
}
