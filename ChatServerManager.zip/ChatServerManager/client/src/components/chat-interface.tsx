import { useState, useEffect, useRef } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Badge } from "@/components/ui/badge";
import { Send, Users, ArrowLeft, ExternalLink } from "lucide-react";
import type { ChatServer } from "@shared/schema";

interface Message {
  id: string;
  type: 'message' | 'bot_message' | 'user_joined' | 'user_left' | 'system';
  userId?: string;
  username?: string;
  botId?: number;
  botName?: string;
  botAvatar?: string;
  message: string;
  link?: string;
  timestamp: string;
}

interface ChatInterfaceProps {
  server: ChatServer;
  username: string;
}

export function ChatInterface({ server, username }: ChatInterfaceProps) {
  const [messages, setMessages] = useState<Message[]>([]);
  const [newMessage, setNewMessage] = useState("");
  const [isConnected, setIsConnected] = useState(false);
  const [participants, setParticipants] = useState<Set<string>>(new Set());
  const [visibleBotMessages, setVisibleBotMessages] = useState<Set<string>>(new Set());
  const wsRef = useRef<WebSocket | null>(null);
  const messagesEndRef = useRef<HTMLDivElement>(null);
  const userId = useRef(Math.random().toString(36).substr(2, 9));

  useEffect(() => {
    // Connect to WebSocket
    const protocol = window.location.protocol === "https:" ? "wss:" : "ws:";
    const wsUrl = `${protocol}//${window.location.host}/ws`;
    const ws = new WebSocket(wsUrl);
    wsRef.current = ws;

    ws.onopen = () => {
      setIsConnected(true);
      // Join the chat room
      ws.send(JSON.stringify({
        type: 'join',
        serverId: server.id,
        userId: userId.current,
        username: username
      }));
    };

    ws.onmessage = (event) => {
      const data = JSON.parse(event.data);
      const messageId = Math.random().toString(36).substr(2, 9);
      
      if (data.type === 'message') {
        setMessages(prev => [...prev, {
          id: messageId,
          type: 'message',
          userId: data.userId,
          username: data.username,
          message: data.message,
          timestamp: data.timestamp
        }]);
      } else if (data.type === 'bot_message') {
        const botMessageId = messageId;
        setMessages(prev => [...prev, {
          id: botMessageId,
          type: 'bot_message',
          botId: data.botId,
          botName: data.botName,
          botAvatar: data.botAvatar,
          message: data.message,
          link: data.link,
          timestamp: data.timestamp
        }]);
        
        // Show bot message
        setVisibleBotMessages(prev => new Set([...prev, botMessageId]));
        
        // Auto-hide bot message after 10 seconds
        setTimeout(() => {
          setVisibleBotMessages(prev => {
            const newSet = new Set(prev);
            newSet.delete(botMessageId);
            return newSet;
          });
        }, 10000);
      } else if (data.type === 'user_joined') {
        setParticipants(prev => new Set([...prev, data.username]));
        setMessages(prev => [...prev, {
          id: messageId,
          type: 'user_joined',
          message: data.message,
          timestamp: new Date().toISOString()
        }]);
      } else if (data.type === 'user_left') {
        setParticipants(prev => {
          const newSet = new Set(prev);
          newSet.delete(data.username);
          return newSet;
        });
        setMessages(prev => [...prev, {
          id: messageId,
          type: 'user_left',
          message: data.message,
          timestamp: new Date().toISOString()
        }]);
      }
    };

    ws.onclose = () => {
      setIsConnected(false);
    };

    return () => {
      if (ws.readyState === WebSocket.OPEN) {
        ws.send(JSON.stringify({
          type: 'leave',
          serverId: server.id,
          userId: userId.current,
          username: username
        }));
      }
      ws.close();
    };
  }, [server.id, username]);

  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages]);

  const sendMessage = () => {
    if (newMessage.trim() && wsRef.current && isConnected) {
      wsRef.current.send(JSON.stringify({
        type: 'message',
        serverId: server.id,
        userId: userId.current,
        username: username,
        message: newMessage.trim()
      }));
      setNewMessage("");
    }
  };

  const handleKeyPress = (e: React.KeyboardEvent) => {
    if (e.key === 'Enter') {
      sendMessage();
    }
  };

  const hideBotMessage = (messageId: string) => {
    setVisibleBotMessages(prev => {
      const newSet = new Set(prev);
      newSet.delete(messageId);
      return newSet;
    });
  };

  const formatTime = (timestamp: string) => {
    return new Date(timestamp).toLocaleTimeString([], { 
      hour: '2-digit', 
      minute: '2-digit' 
    });
  };

  return (
    <div className="h-full flex flex-col">
      {/* Chat Header */}
      <div className="bg-wa-green text-white px-4 py-3 flex items-center justify-between">
        <div className="flex items-center">
          <Button
            variant="ghost"
            size="sm"
            onClick={() => window.history.back()}
            className="text-white hover:bg-wa-dark-green mr-2 p-1"
          >
            <ArrowLeft className="w-4 h-4" />
          </Button>
          <div className="w-10 h-10 bg-white bg-opacity-20 rounded-full flex items-center justify-center mr-3">
            <Users className="w-5 h-5 text-white" />
          </div>
          <div>
            <h3 className="font-semibold">{server.name}</h3>
            <p className="text-xs opacity-90">
              {participants.size} participant{participants.size !== 1 ? 's' : ''}
              {!isConnected && ' • Disconnected'}
            </p>
          </div>
        </div>
        <div className="flex items-center space-x-2">
          <Badge variant="secondary" className="bg-white bg-opacity-20 text-white">
            {isConnected ? 'Connected' : 'Disconnected'}
          </Badge>
        </div>
      </div>

      {/* Messages */}
      <div className="flex-1 overflow-hidden bg-gradient-to-b from-chat-bg to-wa-bg">
        <ScrollArea className="h-full p-4">
          <div className="space-y-3">
            {messages.map((message) => (
              <div key={message.id}>
                {message.type === 'message' && (
                  <div className={`flex ${message.userId === userId.current ? 'justify-end' : 'items-start space-x-2'}`}>
                    {message.userId !== userId.current && (
                      <div className="w-8 h-8 bg-gray-400 rounded-full flex items-center justify-center flex-shrink-0">
                        <span className="text-white text-xs">
                          {message.username?.[0]?.toUpperCase() || 'U'}
                        </span>
                      </div>
                    )}
                    <div className={`rounded-lg px-3 py-2 max-w-xs shadow-sm ${
                      message.userId === userId.current
                        ? 'bg-chat-sent ml-auto'
                        : 'bg-chat-received'
                    }`}>
                      <p className="text-sm">{message.message}</p>
                      <p className="text-xs text-gray-500 mt-1">
                        {message.userId !== userId.current && `${message.username} • `}
                        {formatTime(message.timestamp)}
                      </p>
                    </div>
                  </div>
                )}
                
                {message.type === 'bot_message' && visibleBotMessages.has(message.id) && (
                  <div className="flex items-start space-x-2">
                    <div className="w-8 h-8 bg-wa-green rounded-full flex items-center justify-center flex-shrink-0">
                      <span className="text-white text-xs">{message.botAvatar || '🤖'}</span>
                    </div>
                    <div className="bg-chat-received rounded-lg px-3 py-2 max-w-xs shadow-sm relative">
                      <p className="text-sm">{message.message}</p>
                      {message.link && (
                        <Button
                          size="sm"
                          onClick={() => window.open(message.link, '_blank')}
                          className="mt-2 bg-wa-green hover:bg-wa-dark-green text-white text-xs h-6"
                        >
                          <ExternalLink className="w-3 h-3 mr-1" />
                          Visit Store
                        </Button>
                      )}
                      <p className="text-xs text-gray-500 mt-1">
                        {message.botName} • {formatTime(message.timestamp)}
                      </p>
                      <Button
                        variant="ghost"
                        size="sm"
                        onClick={() => hideBotMessage(message.id)}
                        className="absolute -top-1 -right-1 w-6 h-6 p-0 bg-gray-200 hover:bg-gray-300 rounded-full"
                      >
                        ×
                      </Button>
                    </div>
                  </div>
                )}
                
                {(message.type === 'user_joined' || message.type === 'user_left') && (
                  <div className="text-center">
                    <span className="text-xs text-gray-500 bg-white bg-opacity-70 px-2 py-1 rounded">
                      {message.message}
                    </span>
                  </div>
                )}
              </div>
            ))}
            <div ref={messagesEndRef} />
          </div>
        </ScrollArea>
      </div>

      {/* Message Input */}
      <div className="border-t bg-white px-4 py-3">
        <div className="flex items-center space-x-2">
          <Input
            type="text"
            value={newMessage}
            onChange={(e) => setNewMessage(e.target.value)}
            onKeyPress={handleKeyPress}
            placeholder="Type a message..."
            className="flex-1 border-gray-300 rounded-full focus:ring-2 focus:ring-wa-green focus:border-transparent"
            disabled={!isConnected}
          />
          <Button
            onClick={sendMessage}
            disabled={!newMessage.trim() || !isConnected}
            className="bg-wa-green hover:bg-wa-dark-green text-white w-10 h-10 rounded-full p-0"
          >
            <Send className="w-4 h-4" />
          </Button>
        </div>
        {!isConnected && (
          <p className="text-xs text-red-500 mt-1 text-center">
            Connection lost. Please refresh the page.
          </p>
        )}
      </div>
    </div>
  );
}
