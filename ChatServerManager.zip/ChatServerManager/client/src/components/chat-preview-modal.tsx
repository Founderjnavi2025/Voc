import { useEffect, useState } from "react";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Badge } from "@/components/ui/badge";
import { Send, Users, ExternalLink } from "lucide-react";
import type { ChatServer } from "@shared/schema";

interface ChatPreviewModalProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  server?: ChatServer | null;
}

interface PreviewMessage {
  id: string;
  type: 'message' | 'bot_message' | 'system';
  username?: string;
  botName?: string;
  botAvatar?: string;
  message: string;
  link?: string;
  timestamp: string;
  isOwn?: boolean;
}

export function ChatPreviewModal({ open, onOpenChange, server }: ChatPreviewModalProps) {
  const [messages, setMessages] = useState<PreviewMessage[]>([]);
  const [participants] = useState(12);

  useEffect(() => {
    if (open) {
      // Demo messages
      setMessages([
        {
          id: '1',
          type: 'bot_message',
          botName: 'Support Bot',
          botAvatar: '🤖',
          message: 'Welcome to our support chat! How can I help you today?',
          timestamp: new Date(Date.now() - 180000).toISOString(),
        },
        {
          id: '2',
          type: 'message',
          username: 'You',
          message: 'Hi, I\'m having trouble with my account login',
          timestamp: new Date(Date.now() - 120000).toISOString(),
          isOwn: true,
        },
        {
          id: '3',
          type: 'bot_message',
          botName: 'Support Bot',
          botAvatar: '🤖',
          message: 'I can help you with that! While you wait, check out our latest products:',
          link: 'https://store.example.com',
          timestamp: new Date(Date.now() - 90000).toISOString(),
        },
        {
          id: '4',
          type: 'message',
          username: 'You',
          message: 'Thanks! Can you help me reset my password?',
          timestamp: new Date(Date.now() - 60000).toISOString(),
          isOwn: true,
        },
        {
          id: '5',
          type: 'message',
          username: 'Support Agent',
          message: 'Hello! I\'m here to help. I can send you a password reset link right now.',
          timestamp: new Date(Date.now() - 30000).toISOString(),
        },
      ]);
    }
  }, [open]);

  const formatTime = (timestamp: string) => {
    return new Date(timestamp).toLocaleTimeString([], { 
      hour: '2-digit', 
      minute: '2-digit' 
    });
  };

  const serverName = server?.name || 'Tech Support Chat';

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-md p-0 h-[600px] flex flex-col">
        {/* Chat Header */}
        <DialogHeader className="bg-wa-green text-white px-4 py-3 flex-row items-center justify-between space-y-0 rounded-t-lg">
          <div className="flex items-center">
            <div className="w-10 h-10 bg-white bg-opacity-20 rounded-full flex items-center justify-center mr-3">
              <Users className="w-5 h-5 text-white" />
            </div>
            <div>
              <DialogTitle className="text-white font-semibold">{serverName}</DialogTitle>
              <p className="text-xs opacity-90">{participants} participants</p>
            </div>
          </div>
          <Badge variant="secondary" className="bg-white bg-opacity-20 text-white">
            Preview
          </Badge>
        </DialogHeader>
        
        {/* Chat Messages */}
        <ScrollArea className="flex-1 p-4 bg-gradient-to-b from-chat-bg to-wa-bg">
          <div className="space-y-3">
            {messages.map((message) => (
              <div key={message.id}>
                {message.type === 'message' && (
                  <div className={`flex ${message.isOwn ? 'justify-end' : 'items-start space-x-2'}`}>
                    {!message.isOwn && (
                      <div className="w-8 h-8 bg-blue-500 rounded-full flex items-center justify-center flex-shrink-0">
                        <span className="text-white text-xs">
                          {message.username === 'Support Agent' ? '👨‍💼' : '👤'}
                        </span>
                      </div>
                    )}
                    <div className={`rounded-lg px-3 py-2 max-w-xs shadow-sm ${
                      message.isOwn ? 'bg-chat-sent' : 'bg-chat-received'
                    }`}>
                      <p className="text-sm">{message.message}</p>
                      <p className="text-xs text-gray-500 mt-1">
                        {!message.isOwn && `${message.username} • `}
                        {formatTime(message.timestamp)}
                      </p>
                    </div>
                  </div>
                )}
                
                {message.type === 'bot_message' && (
                  <div className="flex items-start space-x-2">
                    <div className="w-8 h-8 bg-wa-green rounded-full flex items-center justify-center flex-shrink-0">
                      <span className="text-white text-xs">{message.botAvatar}</span>
                    </div>
                    <div className="bg-chat-received rounded-lg px-3 py-2 max-w-xs shadow-sm">
                      <p className="text-sm">{message.message}</p>
                      {message.link && (
                        <Button
                          size="sm"
                          className="mt-2 bg-wa-green hover:bg-wa-dark-green text-white text-xs h-6"
                          onClick={() => window.open(message.link, '_blank')}
                        >
                          <ExternalLink className="w-3 h-3 mr-1" />
                          🛍️ Visit Our Store
                        </Button>
                      )}
                      <p className="text-xs text-gray-500 mt-1">
                        {message.botName} • {formatTime(message.timestamp)}
                      </p>
                    </div>
                  </div>
                )}
              </div>
            ))}
          </div>
        </ScrollArea>
        
        {/* Chat Input */}
        <div className="border-t bg-white px-4 py-3 rounded-b-lg">
          <div className="flex items-center space-x-2">
            <Input
              type="text"
              placeholder="Type a message..."
              className="flex-1 border-gray-300 rounded-full focus:ring-2 focus:ring-wa-green focus:border-transparent"
              disabled
            />
            <Button
              className="bg-wa-green hover:bg-wa-dark-green text-white w-10 h-10 rounded-full p-0"
              disabled
            >
              <Send className="w-4 h-4" />
            </Button>
          </div>
          <p className="text-xs text-gray-500 mt-1 text-center">
            This is a preview - actual chat functionality will be implemented in the live server
          </p>
        </div>
      </DialogContent>
    </Dialog>
  );
}
