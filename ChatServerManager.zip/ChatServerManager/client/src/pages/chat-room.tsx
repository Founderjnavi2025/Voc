import { useEffect, useState } from "react";
import { useParams } from "wouter";
import { useQuery } from "@tanstack/react-query";
import { ChatInterface } from "@/components/chat-interface";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { MessageSquare, Users, AlertCircle } from "lucide-react";
import type { ChatServer } from "@shared/schema";

export default function ChatRoom() {
  const { subdomain } = useParams<{ subdomain: string }>();
  const [username, setUsername] = useState("");
  const [hasJoined, setHasJoined] = useState(false);

  // Fetch server info
  const { data: server, isLoading, error } = useQuery<ChatServer>({
    queryKey: [`/api/public/chat-servers/${subdomain}`],
    enabled: !!subdomain,
  });

  // Check if user has already joined
  useEffect(() => {
    const storedUsername = localStorage.getItem(`chat_username_${subdomain}`);
    if (storedUsername) {
      setUsername(storedUsername);
      setHasJoined(true);
    }
  }, [subdomain]);

  const handleJoinChat = () => {
    if (username.trim()) {
      localStorage.setItem(`chat_username_${subdomain}`, username.trim());
      setHasJoined(true);
    }
  };

  if (isLoading) {
    return (
      <div className="min-h-screen bg-wa-bg flex items-center justify-center">
        <div className="text-center">
          <div className="w-16 h-16 bg-wa-green rounded-full flex items-center justify-center mx-auto mb-4 animate-pulse">
            <MessageSquare className="w-8 h-8 text-white" />
          </div>
          <p className="text-gray-600">Loading chat room...</p>
        </div>
      </div>
    );
  }

  if (error || !server) {
    return (
      <div className="min-h-screen bg-wa-bg flex items-center justify-center p-4">
        <Card className="w-full max-w-md">
          <CardHeader className="text-center">
            <div className="w-16 h-16 bg-red-100 rounded-full flex items-center justify-center mx-auto mb-4">
              <AlertCircle className="w-8 h-8 text-red-500" />
            </div>
            <CardTitle className="text-xl">Chat Room Not Found</CardTitle>
            <CardDescription>
              The chat room you're looking for doesn't exist or has been disabled.
            </CardDescription>
          </CardHeader>
        </Card>
      </div>
    );
  }

  if (!hasJoined) {
    return (
      <div className="min-h-screen bg-wa-bg flex items-center justify-center p-4">
        <Card className="w-full max-w-md">
          <CardHeader className="text-center">
            <div className="w-16 h-16 bg-wa-green rounded-full flex items-center justify-center mx-auto mb-4">
              <MessageSquare className="w-8 h-8 text-white" />
            </div>
            <CardTitle className="text-xl">{server.name}</CardTitle>
            <CardDescription>
              Join the conversation with others in this chat room
            </CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                Your Name
              </label>
              <Input
                type="text"
                value={username}
                onChange={(e) => setUsername(e.target.value)}
                placeholder="Enter your name"
                className="w-full"
                onKeyPress={(e) => e.key === "Enter" && handleJoinChat()}
              />
            </div>
            <Button
              onClick={handleJoinChat}
              disabled={!username.trim()}
              className="w-full bg-wa-green hover:bg-wa-dark-green text-white"
            >
              <Users className="w-4 h-4 mr-2" />
              Join Chat
            </Button>
          </CardContent>
        </Card>
      </div>
    );
  }

  return (
    <div className="h-screen bg-wa-bg">
      <ChatInterface server={server} username={username} />
    </div>
  );
}
