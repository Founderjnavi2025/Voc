import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { MessageSquare, Users, Bot, Zap } from "lucide-react";

export default function Landing() {
  return (
    <div className="min-h-screen bg-gradient-to-br from-wa-bg to-gray-100">
      {/* Header */}
      <header className="bg-white shadow-sm border-b border-gray-200">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center h-16">
            <div className="flex items-center">
              <div className="w-8 h-8 bg-wa-green rounded-full flex items-center justify-center mr-3">
                <MessageSquare className="w-5 h-5 text-white" />
              </div>
              <h1 className="text-xl font-bold text-gray-800">ChatServer Admin</h1>
            </div>
            
            <Button 
              onClick={() => window.location.href = '/api/login'}
              className="bg-wa-green hover:bg-wa-dark-green text-white"
            >
              Admin Login
            </Button>
          </div>
        </div>
      </header>

      {/* Hero Section */}
      <section className="py-20 px-4 sm:px-6 lg:px-8">
        <div className="max-w-4xl mx-auto text-center">
          <h2 className="text-4xl sm:text-5xl font-bold text-gray-900 mb-6">
            Manage Multiple Chat Servers
            <span className="block text-wa-green">With Ease</span>
          </h2>
          <p className="text-xl text-gray-600 mb-8 max-w-2xl mx-auto">
            Create, manage, and monitor public chat servers with advanced bot automation. 
            Perfect for customer support, community engagement, and sales.
          </p>
          <Button 
            onClick={() => window.location.href = '/api/login'}
            size="lg"
            className="bg-wa-green hover:bg-wa-dark-green text-white px-8 py-4 text-lg"
          >
            Get Started - Admin Login
          </Button>
        </div>
      </section>

      {/* Features Section */}
      <section className="py-16 px-4 sm:px-6 lg:px-8 bg-white">
        <div className="max-w-6xl mx-auto">
          <div className="text-center mb-12">
            <h3 className="text-3xl font-bold text-gray-900 mb-4">
              Powerful Features for Chat Management
            </h3>
            <p className="text-lg text-gray-600">
              Everything you need to run successful chat servers
            </p>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
            <Card className="border-2 border-gray-100 hover:border-wa-green transition-colors">
              <CardHeader className="text-center">
                <div className="w-12 h-12 bg-wa-green rounded-full flex items-center justify-center mx-auto mb-4">
                  <MessageSquare className="w-6 h-6 text-white" />
                </div>
                <CardTitle className="text-lg">Multiple Servers</CardTitle>
              </CardHeader>
              <CardContent>
                <CardDescription className="text-center">
                  Create and manage unlimited chat servers with unique subdomains
                </CardDescription>
              </CardContent>
            </Card>

            <Card className="border-2 border-gray-100 hover:border-wa-blue transition-colors">
              <CardHeader className="text-center">
                <div className="w-12 h-12 bg-wa-blue rounded-full flex items-center justify-center mx-auto mb-4">
                  <Users className="w-6 h-6 text-white" />
                </div>
                <CardTitle className="text-lg">Real-time Chat</CardTitle>
              </CardHeader>
              <CardContent>
                <CardDescription className="text-center">
                  WhatsApp-like interface with real-time messaging and mobile support
                </CardDescription>
              </CardContent>
            </Card>

            <Card className="border-2 border-gray-100 hover:border-green-500 transition-colors">
              <CardHeader className="text-center">
                <div className="w-12 h-12 bg-green-500 rounded-full flex items-center justify-center mx-auto mb-4">
                  <Bot className="w-6 h-6 text-white" />
                </div>
                <CardTitle className="text-lg">Smart Bots</CardTitle>
              </CardHeader>
              <CardContent>
                <CardDescription className="text-center">
                  Automated bots with custom messages, timers, and promotional links
                </CardDescription>
              </CardContent>
            </Card>

            <Card className="border-2 border-gray-100 hover:border-yellow-500 transition-colors">
              <CardHeader className="text-center">
                <div className="w-12 h-12 bg-yellow-500 rounded-full flex items-center justify-center mx-auto mb-4">
                  <Zap className="w-6 h-6 text-white" />
                </div>
                <CardTitle className="text-lg">Analytics</CardTitle>
              </CardHeader>
              <CardContent>
                <CardDescription className="text-center">
                  Monitor server performance, user activity, and bot effectiveness
                </CardDescription>
              </CardContent>
            </Card>
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-16 px-4 sm:px-6 lg:px-8 bg-wa-green text-white">
        <div className="max-w-4xl mx-auto text-center">
          <h3 className="text-3xl font-bold mb-4">
            Ready to Start Managing Your Chat Servers?
          </h3>
          <p className="text-xl mb-8 opacity-90">
            Join thousands of businesses using our platform for customer engagement
          </p>
          <Button 
            onClick={() => window.location.href = '/api/login'}
            size="lg"
            className="bg-white text-wa-green hover:bg-gray-100 px-8 py-4 text-lg"
          >
            Access Admin Dashboard
          </Button>
        </div>
      </section>

      {/* Footer */}
      <footer className="bg-gray-800 text-white py-8 px-4 sm:px-6 lg:px-8">
        <div className="max-w-6xl mx-auto text-center">
          <div className="flex items-center justify-center mb-4">
            <div className="w-8 h-8 bg-wa-green rounded-full flex items-center justify-center mr-3">
              <MessageSquare className="w-5 h-5 text-white" />
            </div>
            <h4 className="text-xl font-bold">ChatServer Admin</h4>
          </div>
          <p className="text-gray-400">
            Professional chat server management platform
          </p>
        </div>
      </footer>
    </div>
  );
}
