# ChatServer Admin - Multi-Chat Management Platform

## Overview

This is a full-stack web application for managing multiple public chat servers with bot automation capabilities. The platform allows administrators to create, manage, and monitor chat servers with advanced features like automated messaging, user management, and real-time WebSocket communication.

## System Architecture

### Frontend Architecture
- **Framework**: React with TypeScript
- **Styling**: Tailwind CSS with custom WhatsApp-inspired design system
- **UI Components**: Radix UI primitives with shadcn/ui component library
- **State Management**: TanStack Query for server state management
- **Routing**: Wouter for client-side routing
- **Build Tool**: Vite for development and production builds

### Backend Architecture
- **Runtime**: Node.js with Express.js
- **Language**: TypeScript with ES modules
- **Database**: PostgreSQL with Drizzle ORM
- **Real-time Communication**: WebSocket server for live chat functionality
- **Authentication**: Replit Auth with OpenID Connect
- **Session Management**: PostgreSQL-backed sessions with connect-pg-simple

## Key Components

### Authentication System
- **Provider**: Replit Auth integration with OpenID Connect
- **Session Storage**: PostgreSQL table for persistent sessions
- **User Management**: Automatic user creation and profile management
- **Security**: HTTP-only cookies with secure session handling

### Chat Server Management
- **Multi-tenancy**: Support for multiple chat servers per admin
- **Subdomain Routing**: Unique subdomains for each chat server
- **Configuration**: Customizable server settings (max users, chat duration, etc.)
- **Real-time Monitoring**: Live participant tracking and message analytics

### Bot Automation System
- **Automated Messages**: Scheduled message broadcasting
- **Welcome Messages**: Customizable user onboarding
- **Configurable Intervals**: Flexible timing for automated interactions
- **Link Integration**: Support for embedded links in bot messages

### Real-time Communication
- **WebSocket Server**: Custom WebSocket implementation for live chat
- **Message Broadcasting**: Real-time message distribution to all participants
- **User Presence**: Live participant tracking and status updates
- **Connection Management**: Automatic reconnection and error handling

## Data Flow

1. **Admin Authentication**: Users authenticate through Replit Auth
2. **Server Creation**: Admins create chat servers with custom configurations
3. **Public Access**: Users join chat rooms via subdomain URLs
4. **Real-time Chat**: WebSocket connections handle live messaging
5. **Bot Automation**: Scheduled messages sent based on server configuration
6. **Analytics**: Real-time tracking of participants and message activity

## External Dependencies

### Core Dependencies
- **@neondatabase/serverless**: Neon PostgreSQL database connection
- **drizzle-orm**: Type-safe database queries and migrations
- **@tanstack/react-query**: Server state management and caching
- **@radix-ui/react-***: Accessible UI component primitives
- **express**: Web server framework
- **ws**: WebSocket server implementation

### Authentication
- **openid-client**: OpenID Connect client for Replit Auth
- **passport**: Authentication middleware
- **express-session**: Session management
- **connect-pg-simple**: PostgreSQL session store

### Development Tools
- **tsx**: TypeScript execution for development
- **esbuild**: Production build bundling
- **vite**: Frontend development server and build tool
- **tailwindcss**: Utility-first CSS framework

## Deployment Strategy

### Development Environment
- **Server**: Node.js with tsx for hot reloading
- **Client**: Vite development server with HMR
- **Database**: Neon PostgreSQL with connection pooling
- **WebSocket**: Development WebSocket server on same port

### Production Build
- **Server**: Bundled with esbuild for optimized Node.js execution
- **Client**: Vite production build with asset optimization
- **Static Assets**: Served from Express with proper caching headers
- **Database**: Production PostgreSQL with connection pooling

### Configuration Requirements
- **DATABASE_URL**: PostgreSQL connection string
- **SESSION_SECRET**: Session encryption key
- **REPLIT_DOMAINS**: Allowed domains for authentication
- **ISSUER_URL**: OpenID Connect issuer endpoint

## Changelog

```
Changelog:
- July 07, 2025. Initial setup
```

## User Preferences

```
Preferred communication style: Simple, everyday language.
```